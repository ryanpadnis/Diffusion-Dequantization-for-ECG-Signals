%_topdir %(echo $HOME)/rpmbuild
